Ouvrir le Launcher
Cliquer sur l'engrenage à côté du bouton JOUER
Descendre et cliquer sur OUVRIR LE DOSSIER DU JEU
Aller dans content -> gfx -> items
Coller les fichiers .d2p dedans (garder les originaux quelque part)
